// 网站设置
var name = "讯幻网"; // 网站名称（主站名称）
var home = "http://www.xhkj5.com/"; // 网站地址（主页网址）
var ICP = ""; // 网站备案/许可证号（可以不填）
var Mail = "admin@xhkj5.com"; // 站长邮箱（用于接收更新提醒）

// 版本信息（不要修改）
var Version = 20170319;

// 功能设置　开启功能：true　关闭功能：false
var Ads = false; // 显示广告
var BaiduPush = true; // 百度推送
var Clock = true; // 页面时钟（尚未完成）
var Remind = true; // 零点提醒（尚未完成）
var Share = true; // 分享功能


// 广告设置
// 阿里妈妈广告设置：（mm_memberid_siteid_adzoneid）
// 淘宝联盟开通地址：http://pub.alimama.com/myunion.htm
// 橱窗推广开通地址：http://ssp.tanx.com/ssp.html
var Pid_Link = "mm_00000000_00000000_00000000"; // 淘宝联盟
var Pid_Window = "mm_00000000_00000000_00000000"; // 橱窗推广
