$(function() {
    $("#page").fadeIn(3000); // 淡入页面
});
