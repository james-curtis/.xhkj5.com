var CanRunAds = true;
